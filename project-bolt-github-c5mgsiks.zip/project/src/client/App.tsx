import GumWall from './GumWall';

export const App = () => {
  return <GumWall />;
};
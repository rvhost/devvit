import React, { useState, useEffect, useCallback, useRef } from 'react';
import { GumWad, GumWallState, UserJailState, PoliceState, PolicePhase, GetGumWallResponse, PlaceGumResponse } from '../shared/types/game';

// Unlimited canvas - no size restrictions
const BRICK_SIZE = 80;
const MORTAR_SIZE = 2;

interface AudioContextType {
  context: AudioContext | null;
  initialized: boolean;
}

const GumWall: React.FC = () => {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  
  // Canvas dimensions (will be set to screen size)
  const [canvasWidth, setCanvasWidth] = useState(window.innerWidth);
  const [canvasHeight, setCanvasHeight] = useState(window.innerHeight);
  
  // Game state
  const [gumWalls, setGumWalls] = useState<GumWallState>({ gumWads: [], totalCount: 0, uniqueContributors: 0 });
  const [userJailState, setUserJailState] = useState<UserJailState>({
    isJailed: false,
    jailEndTime: 0,
    lifelinesRemaining: 5,
    lastResetDate: new Date().toDateString(),
  });
  
  // Police state
  const [policeState, setPoliceState] = useState<PoliceState>({
    phase: 'hidden',
    position: -200,
    direction: 'left',
    visible: false,
  });
  
  // Camera/viewport state (starts at 0,0)
  const [cameraX, setCameraX] = useState(0);
  const [cameraY, setCameraY] = useState(0);
  
  // Interaction state
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0, cameraX: 0, cameraY: 0 });
  const [placementMode, setPlacementMode] = useState(false);
  
  // UI state
  const [message, setMessage] = useState('');
  const [messageType, setMessageType] = useState<'warning' | 'success' | 'danger' | 'info'>('info');
  const [jailCountdown, setJailCountdown] = useState(0);
  const [audioContext, setAudioContext] = useState<AudioContextType>({ context: null, initialized: false });
  const [selectedGum, setSelectedGum] = useState<GumWad | null>(null);
  const [hasShownSmartMessage, setHasShownSmartMessage] = useState(false);

  const policeTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const warningTimeoutRef = useRef<NodeJS.Timeout | null>(null);
  const patrolAnimationRef = useRef<number | null>(null);

  // Handle window resize
  useEffect(() => {
    const handleResize = () => {
      setCanvasWidth(window.innerWidth);
      setCanvasHeight(window.innerHeight);
    };
    
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Initialize audio context
  const initAudio = useCallback(() => {
    if (!audioContext.initialized) {
      try {
        const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
        setAudioContext({ context: ctx, initialized: true });
      } catch (error) {
        console.warn('Audio not supported:', error);
        setAudioContext({ context: null, initialized: true });
      }
    }
  }, [audioContext.initialized]);

  // Play warning siren sound
  const playWarningSiren = useCallback(() => {
    if (!audioContext.context) return;
    
    try {
      const oscillator = audioContext.context.createOscillator();
      const gainNode = audioContext.context.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.context.destination);
      
      oscillator.type = 'sine';
      oscillator.frequency.setValueAtTime(800, audioContext.context.currentTime);
      oscillator.frequency.exponentialRampToValueAtTime(400, audioContext.context.currentTime + 0.5);
      oscillator.frequency.exponentialRampToValueAtTime(800, audioContext.context.currentTime + 1);
      
      gainNode.gain.setValueAtTime(0.3, audioContext.context.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.context.currentTime + 1);
      
      oscillator.start();
      oscillator.stop(audioContext.context.currentTime + 1);
    } catch (error) {
      console.warn('Error playing warning siren:', error);
    }
  }, [audioContext.context]);

  // Play arrest sound
  const playArrestSound = useCallback(() => {
    if (!audioContext.context) return;
    
    try {
      const oscillator = audioContext.context.createOscillator();
      const gainNode = audioContext.context.createGain();
      
      oscillator.connect(gainNode);
      gainNode.connect(audioContext.context.destination);
      
      oscillator.type = 'square';
      oscillator.frequency.setValueAtTime(300, audioContext.context.currentTime);
      oscillator.frequency.exponentialRampToValueAtTime(900, audioContext.context.currentTime + 0.2);
      oscillator.frequency.exponentialRampToValueAtTime(200, audioContext.context.currentTime + 0.4);
      
      gainNode.gain.setValueAtTime(0.4, audioContext.context.currentTime);
      gainNode.gain.exponentialRampToValueAtTime(0.01, audioContext.context.currentTime + 0.4);
      
      oscillator.start();
      oscillator.stop(audioContext.context.currentTime + 0.4);
    } catch (error) {
      console.warn('Error playing arrest sound:', error);
    }
  }, [audioContext.context]);

  // Show message with auto-hide
  const showMessage = useCallback((msg: string, type: 'warning' | 'success' | 'danger' | 'info' = 'info', duration = 3000) => {
    setMessage(msg);
    setMessageType(type);
    if (duration > 0) {
      setTimeout(() => setMessage(''), duration);
    }
  }, []);

  // Format time remaining for day ban
  const formatTimeRemaining = useCallback((milliseconds: number) => {
    const totalSeconds = Math.ceil(milliseconds / 1000);
    const hours = Math.floor(totalSeconds / 3600);
    const minutes = Math.floor((totalSeconds % 3600) / 60);
    const seconds = totalSeconds % 60;
    
    if (hours > 0) {
      return `${hours}h ${minutes}m ${seconds}s`;
    } else if (minutes > 0) {
      return `${minutes}m ${seconds}s`;
    } else {
      return `${seconds}s`;
    }
  }, []);

  // Schedule next police warning
  const schedulePoliceWarning = useCallback(() => {
    if (policeTimeoutRef.current) {
      clearTimeout(policeTimeoutRef.current);
    }
    
    // Reset smart message flag for new cycle
    setHasShownSmartMessage(false);
    
    // Random interval between 5-60 seconds
    const interval = 5000 + Math.random() * 55000;
    console.log(`Next police warning in ${interval}ms`);
    
    policeTimeoutRef.current = setTimeout(() => {
      console.log('Starting police warning phase');
      
      // Phase 1: Warning (5-10 MILLISECONDS as requested)
      setPoliceState(prev => ({ ...prev, phase: 'warning' }));
      playWarningSiren();
      showMessage('🚨 POLICE INCOMING!', 'warning', 8000); // Show message for 8 seconds for visibility
      
      // Phase 2: Police patrol starts IMMEDIATELY after warning (5-10 milliseconds)
      const warningDuration = 5 + Math.random() * 5; // 5-10 MILLISECONDS
      console.log(`Warning will last ${warningDuration}ms, then police will appear IMMEDIATELY`);
      
      warningTimeoutRef.current = setTimeout(() => {
        console.log('Warning ended, police car entering screen IMMEDIATELY');
        
        const direction = Math.random() > 0.5 ? 'left' : 'right';
        const startPosition = direction === 'left' ? -200 : canvasWidth + 200;
        
        setPoliceState({
          phase: 'patrolling',
          position: startPosition,
          direction,
          visible: true,
        });
        
        // Animate police car across screen (3-8 seconds to cross)
        const crossingTime = 3000 + Math.random() * 5000; // 3-8 seconds
        const totalDistance = canvasWidth + 400; // Screen width + car buffer
        const speed = totalDistance / crossingTime; // pixels per millisecond
        
        console.log(`Police car will cross screen in ${crossingTime}ms at ${speed} pixels/ms`);
        
        let startTime = performance.now();
        
        const animatePolice = (currentTime: number) => {
          const elapsed = currentTime - startTime;
          const progress = elapsed / crossingTime;
          
          if (progress >= 1) {
            // Police car has finished crossing
            console.log('Police car finished crossing, hiding');
            setPoliceState({
              phase: 'hidden',
              position: -200,
              direction: 'left',
              visible: false,
            });
            
            // Schedule next warning
            setTimeout(() => schedulePoliceWarning(), 1000);
            return;
          }
          
          // Update police car position
          setPoliceState(prev => {
            const newPosition = prev.direction === 'left' 
              ? startPosition + (elapsed * speed)
              : startPosition - (elapsed * speed);
            
            return { ...prev, position: newPosition };
          });
          
          patrolAnimationRef.current = requestAnimationFrame(animatePolice);
        };
        
        patrolAnimationRef.current = requestAnimationFrame(animatePolice);
      }, warningDuration); // 5-10 MILLISECONDS
    }, interval);
  }, [playWarningSiren, showMessage, canvasWidth]);

  // Load gum wall data
  const loadGumWall = useCallback(async () => {
    try {
      const response = await fetch('/api/gum-wall');
      const data = await response.json() as GetGumWallResponse;
      
      if (data.status === 'success') {
        setGumWalls(data.gumWalls);
        setUserJailState(data.userJailState);
      } else {
        showMessage(data.message, 'danger');
      }
    } catch (error) {
      console.error('Error loading gum wall:', error);
      showMessage('Failed to load gum wall', 'danger');
    }
  }, [showMessage]);

  // Place gum on wall
  const placeGum = useCallback(async (screenX: number, screenY: number) => {
    if (userJailState.isJailed && Date.now() < userJailState.jailEndTime) {
      showMessage('You are in jail and cannot place gum!', 'danger');
      return;
    }
    
    console.log(`Placing gum - Police phase: ${policeState.phase}, visible: ${policeState.visible}`);
    
    // Check if police are patrolling (visible on screen)
    if (policeState.phase === 'patrolling' && policeState.visible) {
      console.log('ARREST! User placed gum during police patrol');
      // User placed gum during patrol - arrest them!
      playArrestSound();
      
      try {
        const response = await fetch('/api/arrest', { method: 'POST' });
        const data = await response.json();
        
        if (data.status === 'success') {
          setUserJailState(prev => ({
            ...prev,
            isJailed: true,
            jailEndTime: Date.now() + data.jailTime,
            lifelinesRemaining: data.lifelinesRemaining,
          }));
          
          setJailCountdown(Math.ceil(data.jailTime / 1000));
          showMessage('ARRESTED! You placed gum during police patrol!', 'danger', -1);
        }
      } catch (error) {
        console.error('Error arresting user:', error);
      }
      return;
    }
    
    // Convert screen coordinates to world coordinates
    const worldX = screenX + cameraX;
    const worldY = screenY + cameraY;
    
    try {
      const response = await fetch('/api/place-gum', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ x: worldX, y: worldY }),
      });
      
      const data = await response.json() as PlaceGumResponse;
      
      if (data.status === 'success') {
        setGumWalls(prev => ({
          gumWads: [...prev.gumWads, data.gumWad],
          totalCount: prev.totalCount + 1,
          uniqueContributors: prev.uniqueContributors,
        }));
        
        // Show smart message only once per police cycle and only during warning phase
        if (policeState.phase === 'warning' && !hasShownSmartMessage) {
          console.log('Smart placement during warning phase');
          showMessage('✅ Smart! You avoided arrest!', 'success');
          setHasShownSmartMessage(true);
        }
      } else {
        showMessage(data.message, 'danger');
      }
    } catch (error) {
      console.error('Error placing gum:', error);
      showMessage('Failed to place gum', 'danger');
    }
  }, [userJailState, policeState, cameraX, cameraY, playArrestSound, showMessage, hasShownSmartMessage]);

  // Handle canvas click
  const handleCanvasClick = useCallback((event: React.MouseEvent<HTMLCanvasElement>) => {
    if (isDragging) return;
    
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const rect = canvas.getBoundingClientRect();
    const x = event.clientX - rect.left;
    const y = event.clientY - rect.top;
    
    if (placementMode) {
      placeGum(x, y);
      setPlacementMode(false);
    } else {
      // Check if clicked on existing gum
      const worldX = x + cameraX;
      const worldY = y + cameraY;
      
      const clickedGum = gumWalls.gumWads.find(gum => {
        const distance = Math.sqrt((gum.x - worldX) ** 2 + (gum.y - worldY) ** 2);
        return distance < gum.size / 2;
      });
      
      if (clickedGum) {
        setSelectedGum(clickedGum);
        setTimeout(() => setSelectedGum(null), 3000);
      }
    }
  }, [isDragging, placementMode, placeGum, cameraX, cameraY, gumWalls.gumWads]);

  // Handle mouse drag for panning (fixed direction)
  const handleMouseDown = useCallback((event: React.MouseEvent<HTMLCanvasElement>) => {
    if (placementMode) return;
    
    setIsDragging(true);
    setDragStart({ 
      x: event.clientX, 
      y: event.clientY, 
      cameraX: cameraX, 
      cameraY: cameraY 
    });
  }, [placementMode, cameraX, cameraY]);

  const handleMouseMove = useCallback((event: React.MouseEvent<HTMLCanvasElement>) => {
    if (!isDragging) return;
    
    // Fixed panning direction - drag right moves camera left (shows content to the right)
    const deltaX = event.clientX - dragStart.x;
    const deltaY = event.clientY - dragStart.y;
    
    setCameraX(dragStart.cameraX - deltaX);
    setCameraY(dragStart.cameraY - deltaY);
  }, [isDragging, dragStart]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  // Draw infinite brick wall background
  const drawBrickWall = useCallback((ctx: CanvasRenderingContext2D) => {
    const brickWidth = BRICK_SIZE;
    const brickHeight = 40;
    const mortarWidth = MORTAR_SIZE;
    
    // Calculate visible brick range
    const startCol = Math.floor(cameraX / brickWidth) - 1;
    const endCol = Math.ceil((cameraX + canvasWidth) / brickWidth) + 1;
    const startRow = Math.floor(cameraY / brickHeight) - 1;
    const endRow = Math.ceil((cameraY + canvasHeight) / brickHeight) + 1;
    
    // Fill background with mortar color
    ctx.fillStyle = '#8B4513';
    ctx.fillRect(0, 0, canvasWidth, canvasHeight);
    
    // Draw bricks
    for (let row = startRow; row <= endRow; row++) {
      for (let col = startCol; col <= endCol; col++) {
        const offsetX = (row % 2) * (brickWidth / 2);
        const worldX = col * brickWidth + offsetX;
        const worldY = row * brickHeight;
        
        const screenX = worldX - cameraX;
        const screenY = worldY - cameraY;
        
        if (screenX > -brickWidth && screenX < canvasWidth && 
            screenY > -brickHeight && screenY < canvasHeight) {
          // Brick color with slight variation
          const variation = (Math.abs(col + row * 13) % 20) - 10;
          const red = Math.max(0, Math.min(255, 205 + variation));
          const green = Math.max(0, Math.min(255, 133 + variation));
          const blue = Math.max(0, Math.min(255, 63 + variation));
          
          ctx.fillStyle = `rgb(${red}, ${green}, ${blue})`;
          ctx.fillRect(screenX, screenY, brickWidth - mortarWidth, brickHeight - mortarWidth);
          
          // Brick highlight
          ctx.fillStyle = '#D2B48C';
          ctx.fillRect(screenX, screenY, brickWidth - mortarWidth, 2);
          ctx.fillRect(screenX, screenY, 2, brickHeight - mortarWidth);
        }
      }
    }
  }, [cameraX, cameraY, canvasWidth, canvasHeight]);

  // Draw gum wad with organic shape
  const drawGumWad = useCallback((ctx: CanvasRenderingContext2D, gum: GumWad) => {
    const screenX = gum.x - cameraX;
    const screenY = gum.y - cameraY;
    
    // Only draw if visible on screen
    if (screenX < -gum.size || screenX > canvasWidth + gum.size || 
        screenY < -gum.size || screenY > canvasHeight + gum.size) {
      return;
    }
    
    ctx.save();
    ctx.translate(screenX, screenY);
    
    // Create gradient for shine effect
    const gradient = ctx.createRadialGradient(-gum.size/4, -gum.size/4, 0, 0, 0, gum.size/2);
    gradient.addColorStop(0, gum.color);
    gradient.addColorStop(0.7, gum.color);
    gradient.addColorStop(1, '#000000');
    
    ctx.fillStyle = gradient;
    ctx.strokeStyle = '#000000';
    ctx.lineWidth = 1;
    
    // Draw organic shape using curves
    ctx.beginPath();
    if (gum.shape.points.length > 0) {
      ctx.moveTo(gum.shape.points[0].x, gum.shape.points[0].y);
      
      gum.shape.curves.forEach(curve => {
        ctx.bezierCurveTo(curve.cp1x, curve.cp1y, curve.cp2x, curve.cp2y, curve.x, curve.y);
      });
      
      ctx.closePath();
    } else {
      // Fallback circle
      ctx.arc(0, 0, gum.size / 2, 0, Math.PI * 2);
    }
    
    ctx.fill();
    ctx.stroke();
    
    ctx.restore();
  }, [cameraX, cameraY, canvasWidth, canvasHeight]);

  // Draw police car in header area
  const drawPoliceCar = useCallback((ctx: CanvasRenderingContext2D) => {
    if (!policeState.visible || policeState.phase !== 'patrolling') return;
    
    const carWidth = 160;
    const carHeight = 60;
    const x = policeState.position;
    const y = 80; // Position in header area, below the title
    
    ctx.save();
    
    // Car shadow
    ctx.fillStyle = 'rgba(0, 0, 0, 0.3)';
    ctx.fillRect(x + 3, y + carHeight + 3, carWidth, 8);
    
    // Car body (main white)
    ctx.fillStyle = '#FFFFFF';
    ctx.fillRect(x, y, carWidth, carHeight);
    
    // Car body (police blue stripe)
    ctx.fillStyle = '#0066CC';
    ctx.fillRect(x, y + 15, carWidth, 25);
    
    // Car windows
    ctx.fillStyle = '#87CEEB';
    ctx.fillRect(x + 12, y + 3, carWidth - 24, 12);
    ctx.fillRect(x + 12, y + 45, carWidth - 24, 12);
    
    // Wheels
    ctx.fillStyle = '#000000';
    ctx.beginPath();
    ctx.arc(x + 25, y + carHeight + 3, 15, 0, Math.PI * 2);
    ctx.arc(x + carWidth - 25, y + carHeight + 3, 15, 0, Math.PI * 2);
    ctx.fill();
    
    // Wheel rims
    ctx.fillStyle = '#C0C0C0';
    ctx.beginPath();
    ctx.arc(x + 25, y + carHeight + 3, 10, 0, Math.PI * 2);
    ctx.arc(x + carWidth - 25, y + carHeight + 3, 10, 0, Math.PI * 2);
    ctx.fill();
    
    // Police text
    ctx.fillStyle = '#FFFFFF';
    ctx.font = 'bold 16px Arial';
    ctx.textAlign = 'center';
    ctx.fillText('POLICE', x + carWidth / 2, y + 30);
    
    // Flashing lights
    const time = Date.now() / 150;
    if (Math.floor(time) % 2 === 0) {
      ctx.fillStyle = '#FF0000';
      ctx.beginPath();
      ctx.arc(x + 20, y - 5, 10, 0, Math.PI * 2);
      ctx.fill();
      
      ctx.fillStyle = '#0000FF';
      ctx.beginPath();
      ctx.arc(x + carWidth - 20, y - 5, 10, 0, Math.PI * 2);
      ctx.fill();
    } else {
      ctx.fillStyle = '#FF6666';
      ctx.beginPath();
      ctx.arc(x + 20, y - 5, 10, 0, Math.PI * 2);
      ctx.fill();
      
      ctx.fillStyle = '#6666FF';
      ctx.beginPath();
      ctx.arc(x + carWidth - 20, y - 5, 10, 0, Math.PI * 2);
      ctx.fill();
    }
    
    // Police badge/star
    ctx.fillStyle = '#FFD700';
    ctx.font = 'bold 14px Arial';
    ctx.fillText('★', x + carWidth / 2, y + 12);
    
    ctx.restore();
  }, [policeState]);

  // Main render function
  const render = useCallback(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    if (!ctx) return;
    
    // Clear canvas
    ctx.clearRect(0, 0, canvasWidth, canvasHeight);
    
    // Draw infinite brick wall background
    drawBrickWall(ctx);
    
    // Draw gum wads
    gumWalls.gumWads.forEach(gum => drawGumWad(ctx, gum));
    
    // Draw police car (in header area)
    drawPoliceCar(ctx);
    
    // Draw warning border during police warning (RED ONLY)
    if (policeState.phase === 'warning') {
      ctx.strokeStyle = '#FF0000';
      ctx.lineWidth = 8;
      ctx.setLineDash([10, 10]);
      ctx.strokeRect(4, 4, canvasWidth - 8, canvasHeight - 8);
      ctx.setLineDash([]);
    }
    
    // NO GREEN BORDERS OR + SYMBOL during placement mode
  }, [canvasWidth, canvasHeight, drawBrickWall, gumWalls.gumWads, drawGumWad, drawPoliceCar, policeState.phase]);

  // Jail countdown effect
  useEffect(() => {
    if (userJailState.isJailed && userJailState.jailEndTime > Date.now()) {
      const interval = setInterval(() => {
        const remaining = Math.ceil((userJailState.jailEndTime - Date.now()) / 1000);
        if (remaining <= 0) {
          setJailCountdown(0);
          setUserJailState(prev => ({ ...prev, isJailed: false, jailEndTime: 0 }));
          setMessage('');
          clearInterval(interval);
        } else {
          setJailCountdown(remaining);
        }
      }, 1000);
      
      return () => clearInterval(interval);
    }
  }, [userJailState.isJailed, userJailState.jailEndTime]);

  // Initialize on mount
  useEffect(() => {
    loadGumWall();
    schedulePoliceWarning();
    
    return () => {
      if (policeTimeoutRef.current) clearTimeout(policeTimeoutRef.current);
      if (warningTimeoutRef.current) clearTimeout(warningTimeoutRef.current);
      if (patrolAnimationRef.current) cancelAnimationFrame(patrolAnimationRef.current);
    };
  }, [loadGumWall, schedulePoliceWarning]);

  // Render loop
  useEffect(() => {
    const animate = () => {
      render();
      requestAnimationFrame(animate);
    };
    animate();
  }, [render]);

  // Initialize audio on first user interaction
  useEffect(() => {
    const handleFirstInteraction = () => {
      initAudio();
      document.removeEventListener('click', handleFirstInteraction);
      document.removeEventListener('keydown', handleFirstInteraction);
    };
    
    document.addEventListener('click', handleFirstInteraction);
    document.addEventListener('keydown', handleFirstInteraction);
    
    return () => {
      document.removeEventListener('click', handleFirstInteraction);
      document.removeEventListener('keydown', handleFirstInteraction);
    };
  }, [initAudio]);

  // Check if user is banned for the day (0 lifelines remaining)
  const isBannedForDay = userJailState.lifelinesRemaining === 0 && userJailState.isJailed;
  const timeUntilTomorrow = () => {
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);
    return tomorrow.getTime() - Date.now();
  };

  return (
    <div className="fixed inset-0 bg-gray-900 text-white overflow-hidden">
      {/* Top Header */}
      <div className="absolute top-0 left-0 right-0 z-20 bg-gradient-to-b from-black/90 to-transparent p-4">
        <div className="flex justify-between items-center">
          <div className="flex items-center space-x-4">
            <h1 className="text-xl font-bold">The Internet's Collective Gum Wall</h1>
            <span className="text-sm text-gray-300">Law & Order Edition</span>
          </div>
          <div className="flex items-center space-x-6">
            <div className="flex items-center space-x-2">
              <span className="text-red-400">❤️</span>
              <span className="text-sm">{userJailState.lifelinesRemaining}/5</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-400">Gum:</span>
              <span className="text-green-400 font-bold">{gumWalls.totalCount}</span>
            </div>
            <div className="flex items-center space-x-2">
              <span className="text-sm text-gray-400">Chewers:</span>
              <span className="text-blue-400 font-bold">{gumWalls.uniqueContributors}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Messages */}
      {message && (
        <div className={`absolute top-20 left-1/2 transform -translate-x-1/2 z-30 px-6 py-3 rounded-lg font-bold text-center ${
          messageType === 'warning' ? 'bg-red-600 text-white animate-pulse' :
          messageType === 'success' ? 'bg-green-600 text-white' :
          messageType === 'danger' ? 'bg-red-800 text-white' :
          'bg-blue-600 text-white'
        }`}>
          {message}
          {jailCountdown > 0 && (
            <div className="mt-2 text-lg">
              🔒 Jail Time Remaining: {jailCountdown}s
            </div>
          )}
        </div>
      )}

      {/* Day Ban Screen (when all lifelines are lost) */}
      {isBannedForDay && (
        <div className="absolute inset-0 bg-black bg-opacity-95 flex items-center justify-center z-50">
          <div className="text-center max-w-md">
            <div className="text-8xl mb-6">🚫</div>
            <div className="text-4xl mb-4 font-bold text-red-400">BANNED FOR THE DAY</div>
            <div className="text-xl mb-6 text-gray-300">
              You have lost all lifeline chances and are banned until tomorrow!
            </div>
            <div className="text-2xl text-red-400 font-bold mb-4">
              Time Remaining: {formatTimeRemaining(timeUntilTomorrow())}
            </div>
            <div className="text-lg text-gray-400">
              Your lifelines will reset at midnight. Come back tomorrow to continue placing gum!
            </div>
          </div>
        </div>
      )}

      {/* Regular Jail Screen (temporary jail time) */}
      {userJailState.isJailed && userJailState.jailEndTime > Date.now() && !isBannedForDay && (
        <div className="absolute inset-0 bg-black bg-opacity-95 flex items-center justify-center z-50">
          <div className="text-center">
            <div className="text-8xl mb-6">🐰</div>
            <div className="text-4xl mb-4 font-bold">BEHIND BARS</div>
            <div className="text-xl mb-6 text-gray-300">You were caught placing gum during police patrol!</div>
            <div className="text-3xl text-red-400 font-bold mb-4">
              Release in: {jailCountdown}s
            </div>
            <div className="text-lg text-gray-400">
              Lifelines remaining: {userJailState.lifelinesRemaining}
            </div>
          </div>
        </div>
      )}

      {/* Bottom Controls */}
      <div className="absolute bottom-0 left-0 right-0 z-20 bg-gradient-to-t from-black/90 to-transparent p-4">
        <div className="flex justify-center items-center space-x-4">
          <button
            onClick={() => setPlacementMode(!placementMode)}
            disabled={userJailState.isJailed && userJailState.jailEndTime > Date.now()}
            className={`px-8 py-3 rounded-lg font-bold transition-all duration-200 ${
              placementMode 
                ? 'bg-red-600 hover:bg-red-700 text-white shadow-lg' 
                : 'bg-green-600 hover:bg-green-700 text-white shadow-lg'
            } disabled:bg-gray-600 disabled:cursor-not-allowed`}
          >
            {placementMode ? 'Cancel Placement' : 'Stick Gum'}
          </button>
          <div className="text-sm text-gray-300">
            Click gum to see who placed it • Drag to pan around
          </div>
        </div>
      </div>

      {/* Selected gum info */}
      {selectedGum && (
        <div className="absolute top-32 left-4 z-30 bg-black bg-opacity-90 text-white p-4 rounded-lg">
          <div className="font-bold">Gum by: {selectedGum.username}</div>
          <div className="text-sm text-gray-300">
            Placed: {new Date(selectedGum.timestamp).toLocaleString()}
          </div>
          <div className="text-xs text-gray-400 mt-1">
            Position: ({Math.round(selectedGum.x)}, {Math.round(selectedGum.y)})
          </div>
        </div>
      )}

      {/* Main Canvas */}
      <canvas
        ref={canvasRef}
        width={canvasWidth}
        height={canvasHeight}
        onClick={handleCanvasClick}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
        className="absolute inset-0 z-10"
        style={{ 
          cursor: placementMode ? 'crosshair' : isDragging ? 'grabbing' : 'grab',
          touchAction: 'none'
        }}
      />
    </div>
  );
};

export default GumWall;
import { Context } from '@devvit/public-api';
import { RedisClient } from '@devvit/redis';
import { GumWad, GumWallState, UserJailState, GumShape } from '../../shared/types/game';

// Police logic completely disabled on server side
const POLICEMAN_CATCH_CHANCE = 0;

const getGumWallKey = (postId: string) => `gum_wall:${postId}` as const;
const getUserJailKey = (postId: string, userId: string) => `user_jail:${postId}:${userId}` as const;

const GUM_COLORS = [
  '#E8A5A5', // Faded pink
  '#A5E8A5', // Faded green
  '#D4B896', // Faded brown
  '#C8A5E8', // Faded purple
  '#A5D4E8', // Faded blue
  '#E8D4A5', // Faded yellow
  '#E8A5D4', // Faded magenta
  '#B8B8B8', // Faded gray
];

function generateGumShape(size: number): GumShape {
  const points: { x: number; y: number }[] = [];
  const curves: { cp1x: number; cp1y: number; cp2x: number; cp2y: number; x: number; y: number }[] = [];
  
  const numPoints = 6 + Math.floor(Math.random() * 4);
  const baseRadius = size / 2;
  
  for (let i = 0; i < numPoints; i++) {
    const angle = (i / numPoints) * Math.PI * 2;
    const radiusVariation = 0.7 + Math.random() * 0.6;
    const radius = baseRadius * radiusVariation;
    
    const x = Math.cos(angle) * radius;
    const y = Math.sin(angle) * radius;
    points.push({ x, y });
    
    if (i > 0) {
      const prevPoint = points[i - 1];
      const cp1x = prevPoint.x + (Math.random() - 0.5) * size * 0.3;
      const cp1y = prevPoint.y + (Math.random() - 0.5) * size * 0.3;
      const cp2x = x + (Math.random() - 0.5) * size * 0.3;
      const cp2y = y + (Math.random() - 0.5) * size * 0.3;
      
      curves.push({ cp1x, cp1y, cp2x, cp2y, x, y });
    }
  }
  
  return { points, curves };
}

export const getGumWall = async ({
  redis,
  postId,
  userId,
}: {
  redis: Context['redis'] | RedisClient;
  postId: string;
  userId: string;
}): Promise<{ gumWalls: GumWallState; userJailState: UserJailState }> => {
  const gumWallData = await redis.get(getGumWallKey(postId));
  const userJailData = await redis.get(getUserJailKey(postId, userId));
  
  const gumWalls: GumWallState = gumWallData 
    ? JSON.parse(gumWallData)
    : { gumWads: [], totalCount: 0, uniqueContributors: 0 };
  
  const today = new Date().toDateString();
  let userJailState: UserJailState = userJailData 
    ? JSON.parse(userJailData)
    : { isJailed: false, jailEndTime: 0, lifelinesRemaining: 5, lastResetDate: today };
  
  // Reset lifelines daily
  if (userJailState.lastResetDate !== today) {
    userJailState.lifelinesRemaining = 5;
    userJailState.lastResetDate = today;
    userJailState.isJailed = false;
    userJailState.jailEndTime = 0;
    await redis.set(getUserJailKey(postId, userId), JSON.stringify(userJailState));
  }
  
  // Check if jail time has expired
  if (userJailState.isJailed && Date.now() > userJailState.jailEndTime) {
    userJailState.isJailed = false;
    userJailState.jailEndTime = 0;
    await redis.set(getUserJailKey(postId, userId), JSON.stringify(userJailState));
  }
  
  return { gumWalls, userJailState };
};

export const placeGum = async ({
  redis,
  postId,
  userId,
  username,
  x,
  y,
}: {
  redis: Context['redis'] | RedisClient;
  postId: string;
  userId: string;
  username: string;
  x: number;
  y: number;
}): Promise<{ gumWad: GumWad; arrested: boolean; jailTime: number }> => {
  const { gumWalls, userJailState } = await getGumWall({ redis, postId, userId });
  
  // Check if user is currently jailed
  if (userJailState.isJailed && Date.now() < userJailState.jailEndTime) {
    throw new Error('You are currently in jail and cannot place gum!');
  }
  
  // Server-side police logic disabled - all arrests handled client-side
  const arrested = false;
  let jailTime = 0;
  
  // Create new gum wad
  const gumWad: GumWad = {
    id: `${userId}_${Date.now()}_${Math.random()}`,
    x,
    y,
    color: GUM_COLORS[Math.floor(Math.random() * GUM_COLORS.length)],
    size: 20 + Math.random() * 15,
    userId,
    username,
    timestamp: Date.now(),
    shape: generateGumShape(20 + Math.random() * 15),
  };
  
  // Add to gum wall
  gumWalls.gumWads.push(gumWad);
  gumWalls.totalCount++;
  
  // Update unique contributors
  const uniqueUsers = new Set(gumWalls.gumWads.map(g => g.userId));
  gumWalls.uniqueContributors = uniqueUsers.size;
  
  // Save updated gum wall
  await redis.set(getGumWallKey(postId), JSON.stringify(gumWalls));
  
  return { gumWad, arrested, jailTime };
};

export const arrestUser = async ({
  redis,
  postId,
  userId,
}: {
  redis: Context['redis'] | RedisClient;
  postId: string;
  userId: string;
}): Promise<{ jailTime: number; lifelinesRemaining: number }> => {
  const { userJailState } = await getGumWall({ redis, postId, userId });
  
  if (userJailState.lifelinesRemaining <= 0) {
    // Ban for rest of day
    const tomorrow = new Date();
    tomorrow.setDate(tomorrow.getDate() + 1);
    tomorrow.setHours(0, 0, 0, 0);
    
    userJailState.isJailed = true;
    userJailState.jailEndTime = tomorrow.getTime();
  } else {
    // Calculate jail time (5 seconds * (6 - lifelines remaining))
    const jailDuration = 5000 * (6 - userJailState.lifelinesRemaining);
    userJailState.isJailed = true;
    userJailState.jailEndTime = Date.now() + jailDuration;
    userJailState.lifelinesRemaining--;
  }
  
  await redis.set(getUserJailKey(postId, userId), JSON.stringify(userJailState));
  
  return {
    jailTime: userJailState.jailEndTime - Date.now(),
    lifelinesRemaining: userJailState.lifelinesRemaining,
  };
};
export type LetterState = 'initial' | 'correct' | 'present' | 'absent';

export type CheckResponse = {
  status: 'error';
  message: string;
} | {
  status: 'success';
  exists?: boolean;
  solved: boolean;
  correct: [LetterState, LetterState, LetterState, LetterState, LetterState];
};

export type InitResponse = {
  status: 'error';
  message: string;
} | {
  status: 'success';
  postId: string;
};

// Gum Wall types
export interface GumWad {
  id: string;
  x: number;
  y: number;
  color: string;
  size: number;
  userId: string;
  username: string;
  timestamp: number;
  shape: GumShape;
}

export interface GumShape {
  points: { x: number; y: number }[];
  curves: { cp1x: number; cp1y: number; cp2x: number; cp2y: number; x: number; y: number }[];
}

export interface GumWallState {
  gumWads: GumWad[];
  totalCount: number;
  uniqueContributors: number;
}

export interface UserJailState {
  isJailed: boolean;
  jailEndTime: number;
  lifelinesRemaining: number;
  lastResetDate: string;
}

export type PolicePhase = 'hidden' | 'warning' | 'patrolling';

export interface PoliceState {
  phase: PolicePhase;
  position: number;
  direction: 'left' | 'right';
  visible: boolean;
}

export type PlaceGumResponse = {
  status: 'error';
  message: string;
} | {
  status: 'success';
  gumWad: GumWad;
  arrested?: boolean;
  jailTime?: number;
};

export type GetGumWallResponse = {
  status: 'error';
  message: string;
} | {
  status: 'success';
  gumWalls: GumWallState;
  userJailState: UserJailState;
};